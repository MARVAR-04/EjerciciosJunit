package Ejercicio12;

public class ComponenteA {
    /**
     * Realiza una operación en el ComponenteA.
     * @return El resultado de la operación.
     */
    public String operacionA() {
        // Lógica de la operación A
        return "Resultado de operación A";
    }
}