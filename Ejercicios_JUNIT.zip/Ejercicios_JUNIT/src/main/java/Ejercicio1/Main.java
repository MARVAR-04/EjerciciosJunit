package Ejercicio1;

/*public class Main {
    public static void main(String[] args) {
        // Llama al método main de la clase de prueba CalculatorTest
        org.junit.runner.JUnitCore.main("CalculatorTest");
    }
}*/

