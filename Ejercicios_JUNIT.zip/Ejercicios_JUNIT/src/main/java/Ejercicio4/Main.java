package Ejercicio4;

public class Main {
    public static void main(String[] args) {
        // Crear instancia del gestor de tareas
        GestorDeTareas gestor = new GestorDeTareas();

        // Agregar algunas tareas predeterminadas
        gestor.agregarTarea("Tarea 1");
        gestor.agregarTarea("Tarea 2");
        gestor.agregarTarea("Tarea 3");

        // Mostrar las tareas actuales
        System.out.println("Tareas actuales: " + gestor.obtenerTareas());

        // Eliminar una tarea
        gestor.eliminarTarea("Tarea 2");

        // Mostrar las tareas después de eliminar una
        System.out.println("Tareas después de eliminar: " + gestor.obtenerTareas());

        // Limpiar todas las tareas
        gestor.limpiarTareas();

        // Mostrar las tareas después de limpiar
        System.out.println("Tareas después de limpiar: " + gestor.obtenerTareas());
    }
}

