package Ejercicio3;

public class Main {

    public static void main(String[] args) {
        // Crear una instancia de Validador
        Validador validador = new Validador();

        // Texto válido
        String textoValido = "Hola mundo";

        // Texto nulo
        String textoNulo = null;

        try {
            // Intentar validar el texto válido
            System.out.println("Validando texto válido...");
            validador.validarTexto(textoValido);
            System.out.println("Texto válido validado correctamente.");
        } catch (TextoInvalidoException e) {
            System.out.println("Error al validar texto válido: " + e.getMessage());
        }

        try {
            // Intentar validar el texto nulo
            System.out.println("\nValidando texto nulo...");
            validador.validarTexto(textoNulo);
            System.out.println("Texto nulo validado correctamente.");
        } catch (TextoInvalidoException e) {
            System.out.println("Error al validar texto nulo: " + e.getMessage());
        }
    }
}
