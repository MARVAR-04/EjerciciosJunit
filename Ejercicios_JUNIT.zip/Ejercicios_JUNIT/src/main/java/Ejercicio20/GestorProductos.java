package Ejercicio20;

import java.math.BigDecimal;
import java.util.HashMap;
import java.util.Map;

public class GestorProductos {

    private final Map<String, BigDecimal> productos = new HashMap<>();

    public boolean agregarProducto(String nombre, BigDecimal precio) {
        if (nombre == null || nombre.isEmpty() || precio.compareTo(BigDecimal.ZERO) <= 0) {
            return false;
        }
        productos.put(nombre, precio);
        return true;
    }

    public BigDecimal obtenerPrecio(String nombre) {
        return productos.getOrDefault(nombre, BigDecimal.ZERO);
    }

    public boolean eliminarProducto(String nombre) {
        return productos.remove(nombre) != null;
    }
}
