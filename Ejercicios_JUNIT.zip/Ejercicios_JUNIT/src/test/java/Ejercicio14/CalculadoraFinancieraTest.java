package Ejercicio14;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Nested;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class CalculadoraFinancieraTest {

    private CalculadoraFinanciera calculadora;

    @BeforeEach
    void setUp() {
        calculadora = new CalculadoraFinanciera();
    }

    @Nested
    class CalculoInteresCompuestoTests {
        @Test
        void testInteresCompuestoValoresPositivos() {
            double resultado = calculadora.calcularInteresCompuesto(1000, 0.05, 12, 5);
            assertTrue(resultado > 1000);
        }

        @Test
        void testInteresCompuestoValoresNegativos() {
            double resultado = calculadora.calcularInteresCompuesto(-500, -0.1, 4, 3);
            assertTrue(Double.isNaN(resultado) || resultado < 0);
        }

        @Test
        void testInteresCompuestoTasaCero() {
            double resultado = calculadora.calcularInteresCompuesto(2000, 0, 1, 10);
            assertEquals(2000, resultado);
        }
    }

    @Nested
    class CalculoVPNTests {
        @Test
        void testVPNFlujosCajaPositivos() {
            double[] flujosCaja = {2000, 500, 800, 1200};
            double resultado = calculadora.calcularVPN(0.1, flujosCaja);
            assertTrue(resultado > 0);
        }

        @Test
        void testVPNFlujosCajaNegativos() {
            double[] flujosCaja = {-1500, -200, -400, -800};
            double resultado = calculadora.calcularVPN(0.05, flujosCaja);
            assertTrue(resultado < 0);
        }

        @Test
        void testVPNFlujosCajaMixtos() {
            double[] flujosCaja = {-1000, 300, 500, 800, 200};
            double resultado = calculadora.calcularVPN(0.08, flujosCaja);
            // Aquí podrías agregar una aserción más específica según el caso de prueba
            assertNotNull(resultado);
        }
    }
}
