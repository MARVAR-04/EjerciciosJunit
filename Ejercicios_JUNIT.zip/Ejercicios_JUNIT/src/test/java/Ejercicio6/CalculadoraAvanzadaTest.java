package Ejercicio6;

import org.junit.jupiter.api.Disabled;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class CalculadoraAvanzadaTest {

    private CalculadoraAvanzada calculadora = new CalculadoraAvanzada();

    @Test
    public void testRaizCuadrada() {
        double resultado = calculadora.raizCuadrada(16);
        assertEquals(4.0, resultado);
    }

    @Test
    @Disabled("Implementación pendiente o en revisión")
    public void testLogaritmoNatural() {
        // Esta prueba está deshabilitada porque la implementación del método logaritmoNatural está pendiente o en revisión
        double resultado = calculadora.logaritmoNatural(10);
        assertEquals(2.302585092994046, resultado);
    }

    @Test
    public void testFactorial() {
        long resultado = calculadora.factorial(5);
        assertEquals(120, resultado);
    }
}
