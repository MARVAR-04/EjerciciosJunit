package Ejercicio18;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ProcesadorTareasPesadasTest {

    private ProcesadorTareasPesadas procesador = new ProcesadorTareasPesadas();

    @Test
    void testRealizarOperacionIntensivaDentroDeLimite() {
        long limite = 1000; // Límite de tiempo en milisegundos (por ejemplo, 1 segundo)

        long inicio = System.currentTimeMillis();
        procesador.realizarOperacionIntensiva();
        long fin = System.currentTimeMillis();

        long tiempoTranscurrido = fin - inicio;

        assertTrue(tiempoTranscurrido < limite, "El tiempo transcurrido (" + tiempoTranscurrido +
                " ms) excede el límite aceptable de " + limite + " ms");
    }
}
