package Ejercicio16;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class GeneradorNumerosTest {

    private GeneradorNumeros generador = new GeneradorNumeros();

    @Test
    void testGenerarNumeroAleatorioEnRango() {
        // Prueba la generación de 1000 números aleatorios en diferentes rangos
        for (int i = 0; i < 1000; i++) {
            int min = generador.generarNumeroAleatorioEnRango(-1000, 1000);
            int max = generador.generarNumeroAleatorioEnRango(min, 2000);

            // Verifica que el número generado esté dentro del rango especificado
            assertTrue(min >= -1000 && min <= 1000);
            assertTrue(max >= min && max <= 2000);

            // Verifica que el número generado sea un entero
            assertTrue(min % 1 == 0);
            assertTrue(max % 1 == 0);
        }
    }

    @Test
    void testGenerarNumeroAleatorioEnRangoConMinimoMayorQueMaximo() {
        // Prueba que se lance una excepción si el mínimo es mayor que el máximo
        assertThrows(IllegalArgumentException.class, () -> {
            generador.generarNumeroAleatorioEnRango(100, 50);
        });
    }

    @Test
    void testEsPar() {
        assertTrue(generador.esPar(0));
        assertTrue(generador.esPar(2));
        assertTrue(generador.esPar(-4));
        assertFalse(generador.esPar(1));
        assertFalse(generador.esPar(-3));
    }
}
