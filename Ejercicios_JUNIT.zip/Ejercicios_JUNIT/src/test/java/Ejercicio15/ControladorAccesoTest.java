package Ejercicio15;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class ControladorAccesoTest {

    private ControladorAcceso controladorAcceso;

    @BeforeEach
    void setUp() {
        controladorAcceso = new ControladorAcceso();
    }

    @Test
    void testUsuarioNoExistente() {
        assertFalse(controladorAcceso.verificarAcceso("usuarioNoExistente", "CUALQUIER_FUNCIONALIDAD"));
    }

    @Test
    void testRolAdmin() {
        controladorAcceso.asignarRolAUsuario("usuarioAdmin", "ADMIN");
        assertTrue(controladorAcceso.verificarAcceso("usuarioAdmin", "CUALQUIER_FUNCIONALIDAD"));
    }

    @Test
    void testRolEditor() {
        controladorAcceso.asignarRolAUsuario("usuarioEditor", "EDITOR");
        assertTrue(controladorAcceso.verificarAcceso("usuarioEditor", "OTRA_FUNCIONALIDAD"));
        assertFalse(controladorAcceso.verificarAcceso("usuarioEditor", "GESTION_USUARIOS"));
    }

    @Test
    void testRolVisitante() {
        controladorAcceso.asignarRolAUsuario("usuarioVisitante", "VISITANTE");
        assertTrue(controladorAcceso.verificarAcceso("usuarioVisitante", "CONSULTA"));
        assertFalse(controladorAcceso.verificarAcceso("usuarioVisitante", "OTRA_FUNCIONALIDAD"));
    }

    @Test
    void testRolNoReconocido() {
        controladorAcceso.asignarRolAUsuario("usuarioInvalido", "ROL_DESCONOCIDO");
        assertFalse(controladorAcceso.verificarAcceso("usuarioInvalido", "CUALQUIER_FUNCIONALIDAD"));
    }
}
