package Ejercicio7;

import org.junit.jupiter.api.Test;

import java.time.Duration;

import static org.junit.jupiter.api.Assertions.*;

public class ProcesadorTareasTest {

    private ProcesadorTareas procesador = new ProcesadorTareas();

    @Test
    public void testEjecutarTareaLargaExitosa() {
        assertTimeoutPreemptively(Duration.ofSeconds(5), () -> {
            procesador.ejecutarTareaLarga(3000); // Esperado que tarde menos de 5 segundos
        });
    }

    @Test
    public void testEjecutarTareaLargaFalla() {
        assertTimeoutPreemptively(Duration.ofMillis(2000), () -> {
            procesador.ejecutarTareaLarga(3000); // Esperado que falle porque tardará más de 2 segundos
        });
    }
}
