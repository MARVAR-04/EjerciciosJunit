package Ejercicio9;

import org.junit.jupiter.api.DynamicTest;
import org.junit.jupiter.api.TestFactory;
import java.util.Arrays;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class GeneradorReportesTest {

    private GeneradorReportes generador = new GeneradorReportes();

    @TestFactory
    public List<DynamicTest> testGenerarReporte() {
        List<String> datos = Arrays.asList("dato1", "dato2", "dato3");
        String reporteEsperado = "Reporte:\n- dato1\n- dato2\n- dato3\n";

        // Crear una prueba dinámica para cada dato en la lista
        return Arrays.asList(
                DynamicTest.dynamicTest("Test reporte con datos", () -> {
                    assertEquals(reporteEsperado, generador.generarReporte(datos));
                }),
                DynamicTest.dynamicTest("Test reporte vacío", () -> {
                    List<String> datosVacios = Arrays.asList();
                    assertEquals("Reporte vacío", generador.generarReporte(datosVacios));
                })
        );
    }
}
