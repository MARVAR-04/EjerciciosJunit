package Ejercicio4;

import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import java.util.List;
import static org.junit.jupiter.api.Assertions.*;

public class GestorDeTareasTest {

    private GestorDeTareas gestor;

    @BeforeEach
    public void setUp() {
        gestor = new GestorDeTareas();
        // Agregar algunas tareas predeterminadas para cada prueba
        gestor.agregarTarea("Tarea 1");
        gestor.agregarTarea("Tarea 2");
        gestor.agregarTarea("Tarea 3");
    }

    @AfterEach
    public void tearDown() {
        // Limpiar las tareas después de cada prueba
        gestor.limpiarTareas();
    }

    @Test
    public void testAgregarTarea() {
        // Verificar que se agregó correctamente una tarea nueva
        gestor.agregarTarea("Nueva tarea");
        List<String> tareas = gestor.obtenerTareas();
        assertTrue(tareas.contains("Nueva tarea"));
    }

    @Test
    public void testEliminarTarea() {
        // Verificar que se eliminó correctamente una tarea existente
        assertTrue(gestor.eliminarTarea("Tarea 1"));
        List<String> tareas = gestor.obtenerTareas();
        assertFalse(tareas.contains("Tarea 1"));
    }

    @Test
    public void testObtenerTareas() {
        // Verificar que se obtienen todas las tareas correctamente
        List<String> tareas = gestor.obtenerTareas();
        assertEquals(3, tareas.size());
        assertTrue(tareas.contains("Tarea 1"));
        assertTrue(tareas.contains("Tarea 2"));
        assertTrue(tareas.contains("Tarea 3"));
    }

    @Test
    public void testLimpiarTareas() {
        // Verificar que se eliminaron todas las tareas
        gestor.limpiarTareas();
        List<String> tareas = gestor.obtenerTareas();
        assertTrue(tareas.isEmpty());
    }
}

