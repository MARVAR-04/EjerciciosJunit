package Ejercicio3;

import org.testng.annotations.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ValidadorTest {

    @Test
    public void testValidarTexto() {
        Validador validador = new Validador();

        // Caso de prueba 1: Texto válido
        String textoValido = "Hola mundo";
        assertDoesNotThrow(() -> validador.validarTexto(textoValido));

        // Caso de prueba 2: Texto nulo
        String textoNulo = null;
        TextoInvalidoException exceptionNulo = assertThrows(TextoInvalidoException.class, () -> validador.validarTexto(textoNulo));
        assertEquals("El texto no puede ser nulo ni vacío", exceptionNulo.getMessage());

        // Caso de prueba 3: Texto vacío
        String textoVacio = "";
        TextoInvalidoException exceptionVacio = assertThrows(TextoInvalidoException.class, () -> validador.validarTexto(textoVacio));
        assertEquals("El texto no puede ser nulo ni vacío", exceptionVacio.getMessage());
    }
}
