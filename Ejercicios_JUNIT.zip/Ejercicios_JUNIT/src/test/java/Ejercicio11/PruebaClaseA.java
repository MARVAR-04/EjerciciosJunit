package Ejercicio11;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class PruebaClaseA implements PruebasComunes {

    // Implementación del método ejecucionBasica de PruebasComunes
    @Override
    public boolean ejecucionBasica() {
        // Lógica de prueba específica para esta clase
        return true;
    }

    // Otras pruebas específicas de esta clase
    @Test
    public void pruebaAdicional() {
        // Prueba adicional específica de esta clase
        assertTrue(true);
    }
}
