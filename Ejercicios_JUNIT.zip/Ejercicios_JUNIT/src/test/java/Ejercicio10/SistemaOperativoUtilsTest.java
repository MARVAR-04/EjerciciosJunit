package Ejercicio10;
import org.testng.annotations.Test;
import org.junit.jupiter.api.condition.EnabledOnOs;
import static org.junit.jupiter.api.Assertions.*;

public class SistemaOperativoUtilsTest {

    @Test
    @EnabledOnOs(org.junit.jupiter.api.condition.OS.WINDOWS)
    public void testFuncionalidadSoloEnWindows() {
        assertTrue(SistemaOperativoUtils.esWindows());
        assertFalse(SistemaOperativoUtils.esMac());
        assertFalse(SistemaOperativoUtils.esLinux());
    }

    @Test
    public void testFuncionalidadGeneral() {
        // Esta prueba se ejecutará en todos los sistemas operativos
        // y comprobará el comportamiento general de la funcionalidad.
        assertTrue(SistemaOperativoUtils.esWindows() || SistemaOperativoUtils.esMac() || SistemaOperativoUtils.esLinux());
    }
}
