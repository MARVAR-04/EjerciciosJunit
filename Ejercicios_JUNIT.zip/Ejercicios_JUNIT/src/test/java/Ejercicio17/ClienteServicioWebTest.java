package Ejercicio17;

import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.Mockito.*;

public class ClienteServicioWebTest {

    @Test
    void testObtenerInformacionUsuario() {
        // Crear un mock del ServicioWeb
        ServicioWeb servicioWebMock = mock(ServicioWeb.class);

        // Configurar el comportamiento del mock
        when(servicioWebMock.obtenerDatosUsuario("user123")).thenReturn("Información del usuario");

        // Crear el ClienteServicioWeb con el mock
        ClienteServicioWeb cliente = new ClienteServicioWeb(servicioWebMock);

        // Llamar al método que queremos probar
        String informacion = cliente.obtenerInformacionUsuario("user123");

        // Verificar que se llamó al método del servicio web con el argumento correcto
        verify(servicioWebMock).obtenerDatosUsuario("user123");

        // Verificar que el resultado devuelto es el esperado
        assertEquals("Información del usuario", informacion);
    }
}

