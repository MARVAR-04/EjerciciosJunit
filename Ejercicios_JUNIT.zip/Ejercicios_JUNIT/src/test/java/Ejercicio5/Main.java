package Ejercicio5;

import org.junit.platform.console.ConsoleLauncher;

public class Main {
    public static void main(String[] args) {
        // Ejecutar las pruebas utilizando la consola de JUnit
        ConsoleLauncher.main("Ejercicio5.GestorDeConexionTest");
    }
}
