/*package Ejercicio1;

import static org.junit.Assert.assertEquals;

import Ejercicio1.Calculator;
import org.junit.Test;

public class CalculatorTest {

    @Test
    public void testAdd() {
        Calculator calculator = new Calculator();
        int result = calculator.add(3, 4);
        assertEquals(7, result); // Esperamos que 3 + 4 sea igual a 7
    }
}*/
