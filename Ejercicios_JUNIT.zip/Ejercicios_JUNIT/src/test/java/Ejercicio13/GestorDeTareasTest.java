package Ejercicio13;

import org.junit.jupiter.api.*;

import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;

public class GestorDeTareasTest {

    @Nested
    @DisplayName("Pruebas para agregar tareas")
    class PruebasAgregarTarea {
        @Test
        @DisplayName("Agregar una nueva tarea")
        void testAgregarTarea() {
            GestorDeTareas gestor = new GestorDeTareas();
            gestor.agregarTarea("1", "Tarea de ejemplo");
            assertEquals("Tarea de ejemplo", gestor.buscarTareaPorId("1").orElse(null));
        }
    }

    @Nested
    @DisplayName("Pruebas para eliminar tareas")
    class PruebasEliminarTarea {
        @Test
        @DisplayName("Eliminar tarea existente")
        void testEliminarTareaExistente() {
            GestorDeTareas gestor = new GestorDeTareas();
            gestor.agregarTarea("1", "Tarea de ejemplo");
            assertTrue(gestor.eliminarTarea("1"));
            assertFalse(gestor.buscarTareaPorId("1").isPresent());
        }

        @Test
        @DisplayName("Eliminar tarea inexistente")
        void testEliminarTareaInexistente() {
            GestorDeTareas gestor = new GestorDeTareas();
            assertFalse(gestor.eliminarTarea("1"));
        }
    }

    @Nested
    @DisplayName("Pruebas para buscar tareas por ID")
    class PruebasBuscarTareaPorId {
        @Test
        @DisplayName("Buscar tarea existente")
        void testBuscarTareaExistente() {
            GestorDeTareas gestor = new GestorDeTareas();
            gestor.agregarTarea("1", "Tarea de ejemplo");
            Optional<String> descripcion = gestor.buscarTareaPorId("1");
            assertTrue(descripcion.isPresent());
            assertEquals("Tarea de ejemplo", descripcion.get());
        }

        @Test
        @DisplayName("Buscar tarea inexistente")
        void testBuscarTareaInexistente() {
            GestorDeTareas gestor = new GestorDeTareas();
            Optional<String> descripcion = gestor.buscarTareaPorId("1");
            assertFalse(descripcion.isPresent());
        }
    }
}
