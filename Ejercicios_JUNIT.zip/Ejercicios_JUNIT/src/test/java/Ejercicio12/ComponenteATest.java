package Ejercicio12;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComponenteATest {

    private ComponenteA componenteA = new ComponenteA();

    @Test
    @Tag("ComponenteA")
    public void testOperacionA() {
        assertEquals("Resultado de operación A", componenteA.operacionA());
    }
}
