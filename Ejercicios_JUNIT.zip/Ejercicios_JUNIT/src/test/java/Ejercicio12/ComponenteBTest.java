package Ejercicio12;

import org.junit.jupiter.api.Tag;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;

public class ComponenteBTest {

    private ComponenteB componenteB = new ComponenteB();

    @Test
    @Tag("ComponenteB")
    public void testOperacionB() {
        assertEquals(42, componenteB.operacionB());
    }
}
